'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useState, useEffect } from 'react';
import { useCartStore } from '@/store/cartStore';
import { useAuthStore } from '@/store/authStore';
import { useRouter } from 'next/navigation';

export default function Navbar() {
  const { getTotalItems, toggleCart } = useCartStore();
  const { isAuthenticated, user, logout } = useAuthStore();
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [logoError, setLogoError] = useState(false);

  useEffect(() => { setMounted(true); }, []);
  const handleLogout = () => { logout(); router.push('/'); };

  // Text logo fallback — shows if no image found
  const TextLogo = () => (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <div style={{
        fontFamily: "'Cormorant Garamond', Georgia, serif",
        fontSize: '0.95rem', fontWeight: 300,
        letterSpacing: '0.5em', lineHeight: 1,
      }}>
        <span style={{ color: '#fff' }}>BRAND</span>
        {' '}
        <span style={{ color: '#b8960c' }}>BAZAR</span>
      </div>
      <div style={{ width: '70px', height: '0.5px', background: 'linear-gradient(to right, transparent, #b8960c, transparent)', margin: '5px auto' }} />
      <div style={{ fontSize: '0.42rem', letterSpacing: '0.45em', textTransform: 'uppercase', color: '#b8960c' }}>
        BY MIRSA
      </div>
    </div>
  );

  return (
    <nav style={{
      position: 'fixed', top: 0, width: '100%', zIndex: 100,
      background: '#0a0a0a',
      borderBottom: '0.5px solid rgba(184,150,12,0.2)',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 4vw', height: '76px',
      }}>

        {/* LEFT — hamburger + nav links */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '2rem', flex: 1 }}>
          <button onClick={() => setMenuOpen(!menuOpen)} style={{
            background: 'none', border: 'none', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', gap: '5px', padding: '4px',
          }}>
            <span style={{ display: 'block', width: '22px', height: '1px', background: '#b8960c' }} />
            <span style={{ display: 'block', width: '22px', height: '1px', background: '#b8960c' }} />
            <span style={{ display: 'block', width: '14px', height: '1px', background: '#b8960c' }} />
          </button>
          <div style={{ display: 'flex', gap: '2rem' }}>
            {[
              { label: 'Shop Brands', href: '/products' },
              { label: 'About', href: '/#about' },
              { label: 'Contact', href: '/#contact' },
            ].map(l => (
              <Link key={l.href} href={l.href} style={{
                fontSize: '0.7rem', letterSpacing: '0.2em',
                textTransform: 'uppercase', color: 'rgba(255,255,255,0.7)',
                textDecoration: 'none', transition: 'color 0.2s',
              }}
                onMouseEnter={e => (e.currentTarget.style.color = '#b8960c')}
                onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.7)')}
              >{l.label}</Link>
            ))}
          </div>
        </div>

        {/* CENTER — Logo image OR text fallback */}
        <Link href="/" style={{ textDecoration: 'none', textAlign: 'center', flexShrink: 0 }}>
          {!logoError ? (
            <Image
              src="/logo.png"
              alt="Brand Bazar by Mirsa"
              width={160}
              height={56}
              style={{ objectFit: 'contain', maxHeight: '56px' }}
              onError={() => setLogoError(true)}
              priority
            />
          ) : (
            <TextLogo />
          )}
        </Link>

        {/* RIGHT — search, auth, cart */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.4rem', flex: 1, justifyContent: 'flex-end' }}>
          <button style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="1.5">
              <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
            </svg>
          </button>

          {mounted && isAuthenticated ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <span style={{ fontSize: '0.68rem', letterSpacing: '0.1em', color: 'rgba(255,255,255,0.6)' }}>
                {user?.full_name.split(' ')[0]}
              </span>
              <Link href="/orders" style={{ fontSize: '0.68rem', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.6)', textDecoration: 'none' }}>
                Orders
              </Link>
              <button onClick={handleLogout} style={{
                fontSize: '0.68rem', letterSpacing: '0.15em', textTransform: 'uppercase',
                color: '#b8960c', background: 'none', border: 'none', cursor: 'pointer',
              }}>Logout</button>
            </div>
          ) : (
            <Link href="/auth/login">
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="1.5">
                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
                <circle cx="12" cy="7" r="4"/>
              </svg>
            </Link>
          )}

          <button onClick={toggleCart} style={{ background: 'none', border: 'none', cursor: 'pointer', position: 'relative' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="1.5">
              <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/>
              <line x1="3" y1="6" x2="21" y2="6"/>
              <path d="M16 10a4 4 0 01-8 0"/>
            </svg>
            {mounted && getTotalItems() > 0 && (
              <span style={{
                position: 'absolute', top: '-5px', right: '-7px',
                background: '#b8960c', color: '#fff',
                fontSize: '0.52rem', fontWeight: 600,
                width: '15px', height: '15px', borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{getTotalItems()}</span>
            )}
          </button>
        </div>
      </div>

      {/* Overlay */}
      {menuOpen && (
        <div onClick={() => setMenuOpen(false)} style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 98,
        }} />
      )}

      {/* Slide-out menu */}
      <div style={{
        position: 'fixed', top: 0, left: 0, bottom: 0, width: '300px',
        background: '#0a0a0a', zIndex: 99,
        borderRight: '0.5px solid rgba(184,150,12,0.2)',
        transform: menuOpen ? 'translateX(0)' : 'translateX(-100%)',
        transition: 'transform 0.35s ease',
        padding: '2rem',
      }}>
        <button onClick={() => setMenuOpen(false)} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          color: '#b8960c', fontSize: '1.2rem', marginBottom: '2.5rem',
        }}>✕</button>

        {/* Logo in menu */}
        <div style={{ textAlign: 'center', marginBottom: '3rem', paddingBottom: '2rem', borderBottom: '0.5px solid rgba(184,150,12,0.2)' }}>
          {!logoError ? (
            <Image
              src="/logo.png"
              alt="Brand Bazar by Mirsa"
              width={130}
              height={46}
              style={{ objectFit: 'contain' }}
              onError={() => setLogoError(true)}
            />
          ) : (
            <div>
              <div style={{ fontFamily: "'Cormorant Garamond', Georgia, serif", fontSize: '1rem', fontWeight: 300, letterSpacing: '0.45em', textTransform: 'uppercase' }}>
                <span style={{ color: '#fff' }}>BRAND</span> <span style={{ color: '#b8960c' }}>BAZAR</span>
              </div>
              <div style={{ width: '70px', height: '0.5px', background: 'linear-gradient(to right, transparent, #b8960c, transparent)', margin: '6px auto' }} />
              <div style={{ fontSize: '0.4rem', letterSpacing: '0.4em', color: '#b8960c', textTransform: 'uppercase' }}>BY MIRSA</div>
            </div>
          )}
        </div>

        {/* Menu links */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {[
            { label: "Women's Collection", href: '/products' },
            { label: 'Top Brands', href: '/products' },
            { label: 'New Arrivals', href: '/products' },
            { label: 'About Us', href: '/#about' },
            { label: 'Contact', href: '/#contact' },
          ].map(l => (
            <Link key={l.label} href={l.href} onClick={() => setMenuOpen(false)} style={{
              fontSize: '0.72rem', letterSpacing: '0.22em', textTransform: 'uppercase',
              color: 'rgba(255,255,255,0.75)', textDecoration: 'none',
              padding: '1.2rem 0', borderBottom: '0.5px solid rgba(255,255,255,0.06)',
              transition: 'color 0.2s',
            }}
              onMouseEnter={e => (e.currentTarget.style.color = '#b8960c')}
              onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.75)')}
            >{l.label}</Link>
          ))}
        </div>

        {/* Bottom — socials */}
        <div style={{ position: 'absolute', bottom: '2rem', left: '2rem', right: '2rem' }}>
          <div style={{ fontSize: '0.58rem', letterSpacing: '0.2em', color: '#444', textTransform: 'uppercase', marginBottom: '0.8rem' }}>
            Follow Us
          </div>
          <div style={{ display: 'flex', gap: '1rem' }}>
            {['Instagram', 'Facebook', 'WhatsApp'].map(s => (
              <span key={s} style={{ fontSize: '0.62rem', letterSpacing: '0.1em', color: '#b8960c', cursor: 'pointer' }}>{s}</span>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}
