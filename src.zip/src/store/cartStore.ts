import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CartItem, Product, ProductVariant } from '@/types';

interface CartState {
  items: CartItem[];
  isOpen: boolean;
  addItem: (product: Product, variant?: ProductVariant) => void;
  removeItem: (id: number, variantId?: number) => void;
  updateQuantity: (id: number, quantity: number, variantId?: number) => void;
  clearCart: () => void;
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  getTotalItems: () => number;
  getTotalPrice: () => number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      isOpen: false,

      addItem: (product, variant) => {
        const items = get().items;
        const existingIndex = items.findIndex(
          (item) =>
            item.id === product.id &&
            item.variant?.id === variant?.id
        );

        if (existingIndex !== -1) {
          // Already in cart — increase quantity
          const updated = [...items];
          updated[existingIndex].quantity += 1;
          set({ items: updated });
        } else {
          // New item
          const newItem: CartItem = {
            id: product.id,
            name: product.name,
            price: product.price + (variant?.extra_price || 0),
            quantity: 1,
            image: product.primary_image,
            variant: variant,
            age_range: product.age_range,
          };
          set({ items: [...items, newItem], isOpen: true });
        }
      },

      removeItem: (id, variantId) => {
        set({
          items: get().items.filter(
            (item) =>
              !(item.id === id && item.variant?.id === variantId)
          ),
        });
      },

      updateQuantity: (id, quantity, variantId) => {
        if (quantity <= 0) {
          get().removeItem(id, variantId);
          return;
        }
        set({
          items: get().items.map((item) =>
            item.id === id && item.variant?.id === variantId
              ? { ...item, quantity }
              : item
          ),
        });
      },

      clearCart: () => set({ items: [] }),

      openCart: () => set({ isOpen: true }),
      closeCart: () => set({ isOpen: false }),
      toggleCart: () => set((state) => ({ isOpen: !state.isOpen })),

      getTotalItems: () =>
        get().items.reduce((sum, item) => sum + item.quantity, 0),

      getTotalPrice: () =>
        get().items.reduce(
          (sum, item) => sum + item.price * item.quantity,
          0
        ),
    }),
    {
      name: 'cart-storage', // saved in localStorage
      skipHydration: true,
    }
  )
);