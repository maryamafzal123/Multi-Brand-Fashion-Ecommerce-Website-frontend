'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import CartSidebar from '@/components/CartSidebar';
import WhatsAppButton from '@/components/WhatsAppButton';
import ProductCard from '@/components/ProductCard';
import { Product } from '@/types';
import api from '@/lib/axios';

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    api.get('/api/products/').then(res => {
      setProducts(res.data.results || res.data);
    }).catch(() => setProducts([])).finally(() => setLoading(false));
  }, []);

  const categories = [
    { label: 'All', value: 'all' },
    { label: 'Lawn', value: 'lawn' },
    { label: 'Embroidered', value: 'embroidered' },
    { label: 'Printed', value: 'printed' },
    { label: 'Linen', value: 'linen' },
    { label: 'Chiffon', value: 'chiffon' },
  ];

  const filtered = filter === 'all'
    ? products
    : products.filter(p =>
        p.category?.slug === filter ||
        p.category?.name?.toLowerCase() === filter
      );

  const marqueeItems = [
    'Nishat', '✦', 'Alkaram', '✦', 'Breeze', '✦',
    'Orient', '✦', 'Sapphire', '✦', 'Khaadi', '✦',
    'Free Delivery Over Rs.3000', '✦', 'COD Available', '✦',
    'Nationwide Delivery', '✦', '100% Authentic', '✦',
  ];

  return (
    <>
      <Navbar />
      <CartSidebar />
      <WhatsAppButton />
       {/* ── MARQUEE ── */}
      <div style={{ background: '#faf8f5', overflow: 'hidden', padding: '0.8rem 0', marginTop: '76px', borderTop: '0.5px solid rgba(184,150,12,0.2)', borderBottom: '0.5px solid rgba(184,150,12,0.2)' }}>
        <div style={{ display: 'flex', whiteSpace: 'nowrap', animation: 'marquee 28s linear infinite' }}>
          {[...marqueeItems, ...marqueeItems].map((item, i) => (
            <span key={i} style={{
              fontSize: '0.6rem', letterSpacing: '0.3em',
              textTransform: 'uppercase', color: '#b8960c',
              padding: '0 2.5rem', flexShrink: 0,
            }}>{item}</span>
          ))}
        </div>
      </div>
      {/* ── HERO ── */}
      <section style={{
        paddingTop: '0',
        minHeight: 'auto',
        background: '#ffffff',
        position: 'relative',
        display: 'flex',
        alignItems: 'flex-start',
        overflow: 'hidden',
      }}>
        {/* Decorative gold gradient circles */}
        <div style={{
          position: 'absolute', top: '-200px', right: '-200px',
          width: '600px', height: '600px', borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(184,150,12,0.04) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute', bottom: '-100px', left: '-100px',
          width: '400px', height: '400px', borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(184,150,12,0.02) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />

        {/* Gold vertical line accent */}
        <div style={{
          position: 'absolute', left: '6vw', top: '15%', bottom: '15%',
          width: '0.5px', background: 'linear-gradient(to bottom, transparent, rgba(184,150,12,0.4), transparent)',
        }} />

        <div style={{
          padding: '4rem 8vw 5rem',
          width: '100%', maxWidth: '900px',
          animation: 'fadeUp 1s ease both',
        }}>
          {/* FIX 1 — Top label pushed down from navbar */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: '1rem',
            marginBottom: '2rem',
            marginTop: '0',
          }}>
            <div style={{ width: '30px', height: '0.5px', background: '#b8960c' }} />
            <span style={{ fontSize: '0.62rem', letterSpacing: '0.4em', textTransform: 'uppercase', color: '#b8960c' }}>
              New Collection 2026
            </span>
          </div>

          {/* Main headline */}
          <h1 style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: 'clamp(1.8rem, 3.5vw, 3.2rem)',
            fontWeight: 300, color: '#111',
            letterSpacing: '0.04em', lineHeight: 1.08,
            marginBottom: '0.5rem',
          }}>
            Pakistan&apos;s Finest
          </h1>
          <h1 style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: 'clamp(1.8rem, 3.5vw, 3.2rem)',
            fontWeight: 300, fontStyle: 'italic',
            color: '#b8960c',
            letterSpacing: '0.04em', lineHeight: 1.08,
            marginBottom: '2rem',
          }}>
            Brand Collections
          </h1>

          {/* Gold rule */}
          <div style={{ width: '80px', height: '0.5px', background: '#b8960c', marginBottom: '2rem' }} />

          <p style={{
            fontSize: '0.88rem', color: '#777',
            letterSpacing: '0.08em', lineHeight: 1.9,
            marginBottom: '3rem', maxWidth: '440px',
          }}>
            Nishat · Alkaram · Breeze · Orient · Sapphire · Khaadi<br />
            Shop premium unstitched from Pakistan&apos;s top brands — curated, authentic, delivered to your door.
          </p>

          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
            <Link href="/products" className="btn-gold">Shop Now</Link>
            <Link href="/#about" className="btn-outline-gold">Our Story</Link>
          </div>

          {/* FIX 2 — Stats removed */}

        </div>
      </section>


      {/* ── NEW IN — Category Grid ── */}
      <section style={{ padding: '3rem 6vw', background: '#fff' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '5vw', alignItems: 'start' }}>
          <div>
            <div className="sec-tag">New Arrivals</div>
            <h2 style={{
              fontFamily: "'Cormorant Garamond', Georgia, serif",
              fontSize: 'clamp(2rem, 3.5vw, 3.2rem)',
              fontWeight: 300, color: '#111',
              letterSpacing: '0.04em', lineHeight: 1.2,
              marginBottom: '1.2rem',
            }}>
              Shop the<br />Latest Brands
            </h2>
            <div style={{ width: '40px', height: '0.5px', background: '#b8960c', marginBottom: '1.5rem' }} />
            <p style={{ fontSize: '0.85rem', color: '#888', lineHeight: 1.9, marginBottom: '2rem', letterSpacing: '0.03em' }}>
              Shop authentic unstitched collections from Pakistan&apos;s most loved brands — Nishat, Alkaram, Sapphire, Khaadi and more. All in one place.
            </p>
            <Link href="/products" style={{
              fontSize: '0.68rem', letterSpacing: '0.22em',
              textTransform: 'uppercase', color: '#111',
              textDecoration: 'none',
              borderBottom: '0.5px solid #b8960c',
              paddingBottom: '3px',
            }}>View All Brands →</Link>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
            {[
              { name: 'Lawn', sub: 'Summer Collection', bg: '#faf6f0' },
              { name: 'Embroidered', sub: 'Premium Range', bg: '#f5f0f8' },
              { name: 'Linen', sub: 'Everyday Wear', bg: '#f0f5f0' },
            ].map(cat => (
              <Link key={cat.name} href={`/products?category=${cat.name.toLowerCase()}`} style={{ textDecoration: 'none' }}>
                <div style={{
                  background: cat.bg, aspectRatio: '0.75',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  marginBottom: '0.8rem', overflow: 'hidden',
                  border: '0.5px solid #f0ede8',
                  transition: 'all 0.3s', cursor: 'pointer',
                }}
                  onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = '#b8960c'; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = '#f0ede8'; }}
                >
                  <div style={{ textAlign: 'center', opacity: 0.25 }}>
                    <div style={{
                      fontFamily: "'Cormorant Garamond', Georgia, serif",
                      fontSize: '3rem', fontWeight: 300, color: '#b8960c',
                    }}>
                      {cat.name.charAt(0)}
                    </div>
                  </div>
                </div>
                <div style={{ fontSize: '0.65rem', letterSpacing: '0.22em', textTransform: 'uppercase', color: '#111', marginBottom: '2px' }}>{cat.name}</div>
                <div style={{ fontSize: '0.6rem', letterSpacing: '0.1em', color: '#aaa' }}>{cat.sub}</div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRODUCTS ── */}
      <section id="products" style={{ padding: '5rem 6vw 7rem', background: '#faf8f5' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <div className="sec-tag">✦ &nbsp; Our Collection &nbsp; ✦</div>
          <h2 style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: 'clamp(1.8rem, 3vw, 2.8rem)',
            fontWeight: 300, color: '#111',
            letterSpacing: '0.12em', textTransform: 'uppercase',
          }}>Shop by Brand</h2>
          <div style={{ width: '60px', height: '0.5px', background: '#b8960c', margin: '1rem auto' }} />
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '3rem', justifyContent: 'center' }}>
          {categories.map(cat => (
            <button key={cat.value} onClick={() => setFilter(cat.value)}
              className={`filter-btn${filter === cat.value ? ' active' : ''}`}>
              {cat.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '5rem', fontSize: '0.68rem', letterSpacing: '0.25em', color: '#b8960c', textTransform: 'uppercase' }}>
            Loading collection...
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '5rem' }}>
            <p style={{ fontFamily: "'Cormorant Garamond', Georgia, serif", fontSize: '1.5rem', color: '#ccc', fontStyle: 'italic' }}>
              No products found
            </p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: '1.5rem' }}>
            {filtered.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>
        )}

        <div style={{ textAlign: 'center', marginTop: '3.5rem' }}>
          <Link href="/products" className="btn-black">Shop All Brands</Link>
        </div>
      </section>

      {/* ── ABOUT ── */}
      <section id="about" style={{ padding: '7rem 6vw', background: '#ffffff' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6vw', alignItems: 'center' }}>

          {/* FIX 3 — Left box: black background, gold BB */}
          <div style={{
            background: '#faf8f5',
            border: '0.5px solid rgba(184,150,12,0.3)',
            aspectRatio: '0.9',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative', overflow: 'hidden',
          }}>
            <div style={{ textAlign: 'center', opacity: 0.25 }}>
              <div style={{
                fontFamily: "'Cormorant Garamond', Georgia, serif",
                fontSize: '14rem', fontWeight: 300, color: '#b8960c',
                lineHeight: 1, letterSpacing: '-0.05em',
              }}>BB</div>
            </div>
            <div style={{
              position: 'absolute', bottom: '2.5rem', left: '2.5rem', right: '2.5rem',
              borderTop: '0.5px solid rgba(184,150,12,0.25)', paddingTop: '1.2rem',
            }}>
              <p style={{
                fontFamily: "'Cormorant Garamond', Georgia, serif",
                fontSize: '1rem', fontStyle: 'italic',
                color: 'rgba(255,255,255,0.4)',
              }}>
                &quot;Every woman deserves the best brands.&quot;
              </p>
            </div>
          </div>

          {/* Right — text */}
          <div>
            <div style={{ fontSize: '0.62rem', letterSpacing: '0.38em', textTransform: 'uppercase', color: '#b8960c', marginBottom: '1rem' }}>
              ✦ &nbsp; Our Story
            </div>
            <h2 style={{
              fontFamily: "'Cormorant Garamond', Georgia, serif",
              fontSize: 'clamp(2rem, 3.5vw, 3rem)',
              fontWeight: 300, color: '#111',
              letterSpacing: '0.04em', lineHeight: 1.2,
              marginBottom: '1.5rem',
            }}>
              Your Favourite Brands,<br />
              <span style={{ color: '#b8960c', fontStyle: 'italic' }}>One Destination</span>
            </h2>
            <div style={{ width: '50px', height: '0.5px', background: '#b8960c', marginBottom: '1.8rem' }} />
            <p style={{ fontSize: '0.88rem', color: '#666', lineHeight: 1.9, marginBottom: '2.5rem', letterSpacing: '0.03em' }}>
              Brand Bazar by Mirsa is Pakistan&apos;s curated fashion destination — bringing you authentic unstitched collections from the country&apos;s most loved brands. From Nishat&apos;s signature prints to Sapphire&apos;s premium clothes, from Alkaram&apos;s everyday elegance to Khaadi&apos;s iconic designs — we bring it all to your doorstep. No more running from store to store. Shop your favourite brands in one place, with guaranteed authenticity and nationwide delivery.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
              {[
                { title: '100% Authentic', desc: 'Direct from authorised dealers — every piece is genuine' },
                { title: 'All Top Brands', desc: 'Nishat, Breeze, Alkaram, Gul Ahmed, Sapphire, Khaadi & more' },
                { title: 'Nationwide Delivery', desc: 'Fast & reliable delivery across all of Pakistan — COD available' },
                { title: 'Easy Returns', desc: '7-day hassle-free returns — shop with complete confidence' },
              ].map(item => (
                <div key={item.title} style={{
                  display: 'flex', gap: '1rem',
                  borderBottom: '0.5px solid rgba(0,0,0,0.06)',
                  padding: '1rem 0',
                }}>
                  <span style={{ color: '#b8960c', fontSize: '0.7rem', marginTop: '0.2rem', flexShrink: 0 }}>✦</span>
                  <div>
                    <div style={{ fontSize: '0.7rem', fontWeight: 500, letterSpacing: '0.15em', textTransform: 'uppercase', color: '#111', marginBottom: '0.25rem' }}>{item.title}</div>
                    <div style={{ fontSize: '0.8rem', color: '#888', lineHeight: 1.6 }}>{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CONTACT ── */}
      <section id="contact" style={{ padding: '7rem 6vw', background: '#faf8f5' }}>
        <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
          <div className="sec-tag">✦ &nbsp; Get in Touch</div>
          <h2 style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: 'clamp(1.8rem, 3vw, 2.8rem)',
            fontWeight: 300, color: '#111', letterSpacing: '0.08em',
          }}>We&apos;d Love to Hear From You</h2>
          <div style={{ width: '60px', height: '0.5px', background: '#b8960c', margin: '1rem auto' }} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '5vw', maxWidth: '900px', margin: '0 auto' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {[
              { icon: '📍', label: 'Location', value: 'Pakistan' },
              { icon: '📱', label: 'WhatsApp', value: '+92 333 6262574' },
              { icon: '✉️', label: 'Email', value: 'hello@brandbazar.pk' },
              { icon: '🕐', label: 'Hours', value: 'Mon – Sat, 10am – 8pm' },
            ].map(item => (
              <div key={item.label} style={{
                display: 'flex', gap: '1rem', alignItems: 'flex-start',
                padding: '1.2rem', background: '#fff',
                border: '0.5px solid #e8e4de',
                transition: 'border-color 0.2s',
              }}
                onMouseEnter={e => ((e.currentTarget as HTMLDivElement).style.borderColor = '#b8960c')}
                onMouseLeave={e => ((e.currentTarget as HTMLDivElement).style.borderColor = '#e8e4de')}
              >
                <span style={{ fontSize: '1.1rem' }}>{item.icon}</span>
                <div>
                  <div style={{ fontSize: '0.58rem', letterSpacing: '0.25em', textTransform: 'uppercase', color: '#b8960c', marginBottom: '0.3rem' }}>{item.label}</div>
                  <div style={{ fontSize: '0.85rem', color: '#444' }}>{item.value}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
            {['Your Name', 'Email Address', 'Subject'].map(ph => (
              <input key={ph} placeholder={ph} style={{
                width: '100%', padding: '0.9rem 1.2rem',
                background: '#ffffff',
                border: '0.5px solid #e8e4de',
                color: '#111', fontFamily: 'Jost, sans-serif',
                fontSize: '0.85rem', outline: 'none',
                transition: 'border-color 0.2s',
              }}
                onFocus={e => (e.currentTarget.style.borderColor = '#b8960c')}
                onBlur={e => (e.currentTarget.style.borderColor = '#e8e4de')}
              />
            ))}
            <textarea placeholder="Your Message..." rows={4} style={{
              width: '100%', padding: '0.9rem 1.2rem',
              background: '#ffffff',
              border: '0.5px solid #e8e4de',
              color: '#111', fontFamily: 'Jost, sans-serif',
              fontSize: '0.85rem', outline: 'none', resize: 'vertical',
            }}
              onFocus={e => (e.currentTarget.style.borderColor = '#b8960c')}
              onBlur={e => (e.currentTarget.style.borderColor = '#e8e4de')}
            />
            <button className="btn-gold" style={{ width: '100%', padding: '1rem', border: 'none' }}>
              Send Message
            </button>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{ background: '#111', borderTop: '0.5px solid rgba(184,150,12,0.2)', padding: '3.5rem 6vw 2rem' }}>
        <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
          <div style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: '1.1rem', fontWeight: 300,
            letterSpacing: '0.5em', textTransform: 'uppercase',
          }}>
            <span style={{ color: '#fff' }}>BRAND </span>
            <span style={{ color: '#b8960c' }}>BAZAR</span>
          </div>
          <div style={{ width: '70px', height: '0.5px', background: 'linear-gradient(to right, transparent, #b8960c, transparent)', margin: '8px auto' }} />
          <div style={{ fontSize: '0.42rem', letterSpacing: '0.45em', color: '#555', textTransform: 'uppercase' }}>BY MIRSA</div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'center', gap: '2.5rem', marginBottom: '2.5rem' }}>
          {['Collection', 'About', 'Contact', 'Orders'].map(l => (
            <span key={l} style={{
              fontSize: '0.62rem', letterSpacing: '0.18em',
              textTransform: 'uppercase', color: '#666',
              cursor: 'pointer', transition: 'color 0.2s',
            }}
              onMouseEnter={e => (e.currentTarget.style.color = '#b8960c')}
              onMouseLeave={e => (e.currentTarget.style.color = '#666')}
            >{l}</span>
          ))}
        </div>

        <div style={{
          borderTop: '0.5px solid #222', paddingTop: '1.5rem',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          flexWrap: 'wrap', gap: '1rem',
          fontSize: '0.62rem', letterSpacing: '0.1em', color: '#444',
        }}>
          <div>© 2026 Brand Bazar by Mirsa. All rights reserved.</div>
          <div style={{ display: 'flex', gap: '1.5rem' }}>
            {['Instagram', 'Facebook', 'WhatsApp'].map(s => (
              <span key={s} style={{ cursor: 'pointer', transition: 'color 0.2s' }}
                onMouseEnter={e => (e.currentTarget.style.color = '#b8960c')}
                onMouseLeave={e => (e.currentTarget.style.color = '#444')}
              >{s}</span>
            ))}
          </div>
          <div>Pakistan&apos;s Most Trusted Multi-Brand Fashion Store</div>
        </div>
      </footer>
    </>
  );
}
