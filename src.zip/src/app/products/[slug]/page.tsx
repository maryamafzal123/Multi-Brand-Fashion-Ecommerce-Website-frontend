'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import toast from 'react-hot-toast';
import Navbar from '@/components/Navbar';
import CartSidebar from '@/components/CartSidebar';
import WhatsAppButton from '@/components/WhatsAppButton';
import { Product, ProductVariant } from '@/types';
import { useCartStore } from '@/store/cartStore';
import api from '@/lib/axios';

export default function ProductDetailPage() {
  const { slug } = useParams();
  const router = useRouter();
  const { addItem } = useCartStore();

  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await api.get(`/api/products/${slug}/`);
        setProduct(res.data);
        setSelectedImage(res.data.primary_image);
      } catch {
        router.push('/products');
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [slug, router]);

  const handleAddToCart = () => {
    if (!product) return;
    for (let i = 0; i < quantity; i++) {
      addItem(product, selectedVariant || undefined);
    }
    toast.success(`${product.name} added to bag ✓`);
  };

  const finalPrice = product
    ? Number(product.price) + (selectedVariant ? Number(selectedVariant.extra_price) : 0)
    : 0;

  if (loading) return (
    <div style={{
      minHeight: '100vh', display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      background: '#faf8f5',
    }}>
      <p style={{
        fontFamily: "'Cormorant Garamond', Georgia, serif",
        fontSize: '1.5rem', color: '#b8960c', fontStyle: 'italic',
      }}>
        Loading...
      </p>
    </div>
  );

  if (!product) return null;

  return (
    <>
      <Navbar />
      <CartSidebar />
      <WhatsAppButton />

      <div style={{ paddingTop: '72px', minHeight: '100vh', background: '#faf8f5' }}>

        {/* Breadcrumb */}
        <div style={{
          padding: '1.5rem 6vw',
          fontSize: '0.72rem', letterSpacing: '0.15em',
          textTransform: 'uppercase', color: '#b8960c',
        }}>
          <Link href="/" style={{ color: '#b8960c', textDecoration: 'none' }}>Home</Link>
          {' / '}
          <Link href="/products" style={{ color: '#b8960c', textDecoration: 'none' }}>Collection</Link>
          {' / '}
          <span style={{ color: '#111' }}>{product.name}</span>
        </div>

        {/* Main Content */}
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr',
          gap: '5vw', padding: '2rem 6vw 7rem',
        }}>

          {/* Images */}
          <div>
            {/* Main Image */}
            <div style={{
              height: '580px', position: 'relative',
              background: 'linear-gradient(135deg, #f5f0e8, #faf8f5)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              marginBottom: '1rem', overflow: 'hidden',
            }}>
              {selectedImage ? (
                <Image
                  src={selectedImage}
                  alt={product.name}
                  fill
                  style={{ objectFit: 'cover' }}
                />
              ) : (
                <span style={{ fontSize: '8rem', opacity: 0.4 }}>{'👗'}</span>
              )}

              {product.discount_percent > 0 && (
                <span style={{
                  position: 'absolute', top: '16px', left: '16px',
                  background: '#b8960c', color: '#fff',
                  fontSize: '0.72rem', letterSpacing: '0.15em',
                  textTransform: 'uppercase', padding: '0.4rem 1rem',
                }}>
                  -{product.discount_percent}% OFF
                </span>
              )}
            </div>

            {/* Thumbnail Images */}
            {product.images && product.images.length > 1 && (
              <div style={{ display: 'flex', gap: '0.8rem', flexWrap: 'wrap' }}>
                {product.images.map((img) => (
                  <div
                    key={img.id}
                    onClick={() => setSelectedImage(img.image)}
                    style={{
                      width: '80px', height: '80px',
                      position: 'relative', cursor: 'pointer',
                      border: selectedImage === img.image
                        ? '2px solid #b8960c'
                        : '2px solid transparent',
                      overflow: 'hidden',
                      background: '#faf8f5',
                    }}
                  >
                    <Image
                      src={img.image} alt={product.name}
                      fill style={{ objectFit: 'cover' }}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div>
            {/* Category */}
            {product.category && (
              <p style={{
                fontSize: '0.72rem', letterSpacing: '0.2em',
                textTransform: 'uppercase', color: '#b8960c',
                marginBottom: '0.8rem',
              }}>
                {product.category.name}
              </p>
            )}

            {/* Name */}
            <h1 style={{
              fontFamily: "'Cormorant Garamond', Georgia, serif",
              fontSize: 'clamp(2rem, 3.5vw, 3rem)',
              fontWeight: 300, color: '#111',
              lineHeight: 1.2, marginBottom: '1rem',
            }}>
              {product.name}
            </h1>

            {/* Age */}
            <p style={{
              fontSize: '0.78rem', letterSpacing: '0.15em',
              textTransform: 'uppercase', color: '#8b5e3c',
              marginBottom: '1.5rem',
            }}>
              Age: {product.age_range} years
            </p>

            {/* Price */}
            <div style={{ marginBottom: '2rem' }}>
              <span style={{
                fontFamily: "'Cormorant Garamond', Georgia, serif",
                fontSize: '2.2rem', fontWeight: 300, color: '#b8960c',
              }}>
                Rs. {finalPrice.toLocaleString()}
              </span>
              {product.old_price && (
                <span style={{
                  fontSize: '1.2rem', color: '#aaa',
                  textDecoration: 'line-through', marginLeft: '1rem',
                }}>
                  Rs. {Number(product.old_price).toLocaleString()}
                </span>
              )}
            </div>

            {/* Description */}
            <p style={{
              fontSize: '0.92rem', color: '#7a6458',
              lineHeight: 1.9, fontWeight: 300,
              marginBottom: '2rem',
              borderTop: '1px solid rgba(196,169,125,0.2)',
              paddingTop: '1.5rem',
            }}>
              {product.description}
            </p>

            {/* Variants */}
            {product.variants && product.variants.length > 0 && (
              <div style={{ marginBottom: '2rem' }}>
                <p style={{
                  fontSize: '0.72rem', letterSpacing: '0.18em',
                  textTransform: 'uppercase', color: '#111',
                  marginBottom: '0.8rem',
                }}>
                  Select Size / Color
                </p>
                <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap' }}>
                  {product.variants.map((variant) => (
                    <button
                      key={variant.id}
                      onClick={() => setSelectedVariant(
                        selectedVariant?.id === variant.id ? null : variant
                      )}
                      disabled={variant.stock === 0}
                      style={{
                        padding: '0.5rem 1.2rem',
                        fontSize: '0.78rem',
                        background: selectedVariant?.id === variant.id
                          ? '#111' : 'transparent',
                        color: selectedVariant?.id === variant.id
                          ? '#faf8f5' : '#111',
                        border: selectedVariant?.id === variant.id
                          ? '1px solid #111'
                          : '1px solid rgba(58,42,32,0.25)',
                        cursor: variant.stock === 0 ? 'not-allowed' : 'pointer',
                        opacity: variant.stock === 0 ? 0.4 : 1,
                        transition: 'all 0.2s',
                      }}
                    >
                      {variant.size}
                      {variant.color && ` / ${variant.color}`}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div style={{ marginBottom: '2rem' }}>
              <p style={{
                fontSize: '0.72rem', letterSpacing: '0.18em',
                textTransform: 'uppercase', color: '#111',
                marginBottom: '0.8rem',
              }}>
                Quantity
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  style={{
                    width: '36px', height: '36px',
                    background: '#faf8f5', border: 'none',
                    fontSize: '1.2rem', cursor: 'pointer',
                    color: '#111',
                  }}
                >−</button>
                <span style={{
                  fontFamily: "'Cormorant Garamond', Georgia, serif",
                  fontSize: '1.4rem', minWidth: '30px', textAlign: 'center',
                }}>
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  style={{
                    width: '36px', height: '36px',
                    background: '#faf8f5', border: 'none',
                    fontSize: '1.2rem', cursor: 'pointer',
                    color: '#111',
                  }}
                >+</button>
              </div>
            </div>

            {/* Stock */}
            <p style={{
              fontSize: '0.75rem', letterSpacing: '0.1em',
              color: product.in_stock ? '#5a9a6a' : '#b8960c',
              marginBottom: '1.5rem',
            }}>
              {product.in_stock ? `✓ In Stock (${product.stock} available)` : '✗ Out of Stock'}
            </p>

            {/* Add to Cart */}
            <button
              onClick={handleAddToCart}
              disabled={!product.in_stock}
              style={{
                width: '100%', padding: '1.1rem',
                background: product.in_stock ? '#111' : '#ccc',
                color: '#faf8f5',
                fontSize: '0.78rem', letterSpacing: '0.18em',
                textTransform: 'uppercase', border: 'none',
                cursor: product.in_stock ? 'pointer' : 'not-allowed',
                marginBottom: '1rem', transition: 'background 0.3s',
              }}
              onMouseEnter={e => {
                if (product.in_stock)
                  (e.currentTarget as HTMLButtonElement).style.background = '#b8960c';
              }}
              onMouseLeave={e => {
                if (product.in_stock)
                  (e.currentTarget as HTMLButtonElement).style.background = '#111';
              }}
            >
              {product.in_stock ? 'Add to Bag' : 'Out of Stock'}
            </button>

            {/* WhatsApp Order */}
            <a
              href={`https://wa.me/923000000000?text=Hi! I want to order: ${product.name}`}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: 'block', width: '100%', padding: '1.1rem',
                background: '#25d366', color: '#fff',
                fontSize: '0.78rem', letterSpacing: '0.18em',
                textTransform: 'uppercase', border: 'none',
                cursor: 'pointer', textAlign: 'center',
                textDecoration: 'none', transition: 'opacity 0.3s',
              }}>
              {'💬 Order via WhatsApp'}
            </a>

            {/* Delivery info */}
            <div style={{
              marginTop: '2rem',
              borderTop: '1px solid rgba(196,169,125,0.2)',
              paddingTop: '1.5rem',
              display: 'flex', flexDirection: 'column', gap: '0.8rem',
            }}>
              {[
                { icon: '🚚', text: 'Free delivery on orders over Rs. 3,000' },
                { icon: '↩️', text: 'Easy returns within 7 days' },
                { icon: '✨', text: 'Premium quality guaranteed' },
              ].map((item) => (
                <div key={item.text} style={{
                  display: 'flex', alignItems: 'center', gap: '0.8rem',
                  fontSize: '0.82rem', color: '#7a6458',
                }}>
                  <span>{item.icon}</span>
                  <span>{item.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer style={{
  background: '#111', borderTop: '0.5px solid rgba(184,150,12,0.2)',
  padding: '2rem 6vw', display: 'flex',
  alignItems: 'center', justifyContent: 'space-between',
  flexWrap: 'wrap', gap: '1rem',
}}>
  <div style={{ textAlign: 'center' }}>
    <div style={{ fontFamily: "'Cormorant Garamond', Georgia, serif", fontSize: '0.9rem', fontWeight: 300, letterSpacing: '0.4em', textTransform: 'uppercase' }}>
      <span style={{ color: '#fff' }}>BRAND </span>
      <span style={{ color: '#b8960c' }}>BAZAR</span>
    </div>
    <div style={{ height: '0.5px', background: 'linear-gradient(to right, transparent 10%, #b8960c 50%, transparent 90%)', margin: '3px auto', width: '120px' }} />
    <div style={{ fontSize: '0.4rem', letterSpacing: '0.35em', color: '#b8960c', textTransform: 'uppercase' }}>BY MIRSA</div>
  </div>
  <div style={{ fontSize: '0.65rem', color: '#444', letterSpacing: '0.1em' }}>© 2026 Brand Bazar. All rights reserved.</div>
</footer>
    </>
  );
}