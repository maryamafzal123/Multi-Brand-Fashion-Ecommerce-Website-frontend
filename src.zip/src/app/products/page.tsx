'use client';

import { useEffect, useState } from 'react';
import Navbar from '@/components/Navbar';
import CartSidebar from '@/components/CartSidebar';
import WhatsAppButton from '@/components/WhatsAppButton';
import ProductCard from '@/components/ProductCard';
import { Product } from '@/types';
import api from '@/lib/axios';
import Link from 'next/link';

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('newest');

  useEffect(() => {
    api.get('/api/products/').then(res => {
      setProducts(res.data.results || res.data);
    }).catch(() => setProducts([])).finally(() => setLoading(false));
  }, []);

  const categories = [
    { label: 'All Brands', value: 'all' },
    { label: 'Lawn Unstitched', value: 'lawn' },
    { label: 'Embroidered Lawn', value: 'embroidered' },
    { label: 'Printed Lawn', value: 'printed' },
    { label: 'Linen Collection', value: 'linen' },
    { label: 'Chiffon & Formal', value: 'chiffon' },
  ];

  const filtered = products
    .filter(p => {
      const matchCat = filter === 'all' || p.category?.slug === filter || p.category?.name?.toLowerCase() === filter;
      const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
      return matchCat && matchSearch;
    })
    .sort((a, b) => {
      if (sort === 'price-asc') return Number(a.price) - Number(b.price);
      if (sort === 'price-desc') return Number(b.price) - Number(a.price);
      return 0;
    });

  return (
    <>
      <Navbar />
      <CartSidebar />
      <WhatsAppButton />

      {/* Header */}
      <div style={{ paddingTop: '72px', background: '#fff', borderBottom: '0.5px solid #e8e4de' }}>
        <div style={{ padding: '4rem 6vw 2.5rem' }}>
          {/* Breadcrumb */}
          <div style={{ fontSize: '0.65rem', letterSpacing: '0.18em', color: '#111', marginBottom: '1rem' }}>
  <Link href="/" style={{ color: '#111', textDecoration: 'none' }}
    onMouseEnter={e => (e.currentTarget.style.color = '#b8960c')}
    onMouseLeave={e => (e.currentTarget.style.color = '#999')}
  >Home</Link>
  &nbsp;›&nbsp; All Brands
</div>
          <h1 style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontSize: 'clamp(1.8rem, 3.5vw, 3rem)',
            fontWeight: 300, color: '#111',
            letterSpacing: '0.08em', textTransform: 'uppercase',
          }}>
            Shop By Brand
          </h1>
          <div style={{ width: '50px', height: '0.5px', background: '#b8960c', margin: '1rem 0' }} />
        </div>

        {/* Filters + Sort bar — exactly like Sapphire */}
        <div style={{
          padding: '0 6vw 1.5rem',
          display: 'flex', alignItems: 'center',
          justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem',
        }}>
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
            <span style={{ fontSize: '0.65rem', letterSpacing: '0.18em', textTransform: 'uppercase', color: '#999', marginRight: '0.5rem' }}>
              Filter +
            </span>
            {categories.map(cat => (
              <button key={cat.value} onClick={() => setFilter(cat.value)} className={`filter-btn${filter === cat.value ? ' active' : ''}`}>
                {cat.label}
              </button>
            ))}
          </div>

          <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
            <input
              type="text" placeholder="Search..."
              value={search} onChange={e => setSearch(e.target.value)}
              style={{
                padding: '0.45rem 1rem', border: '0.5px solid #e8e4de',
                background: '#faf8f5', color: '#111',
                fontSize: '0.78rem', outline: 'none',
                fontFamily: 'Jost, sans-serif', width: '180px',
              }}
            />
            <select value={sort} onChange={e => setSort(e.target.value)} style={{
              padding: '0.45rem 1rem', border: '0.5px solid #e8e4de',
              background: '#fff', color: '#111', fontSize: '0.72rem',
              letterSpacing: '0.12em', outline: 'none',
              fontFamily: 'Jost, sans-serif', cursor: 'pointer',
            }}>
              <option value="newest">Sort: Newest</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div style={{ padding: '3rem 6vw 7rem', background: '#faf8f5', minHeight: '60vh' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '5rem', fontSize: '0.72rem', letterSpacing: '0.2em', color: '#999', textTransform: 'uppercase' }}>
            Loading collection...
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '5rem' }}>
            <p style={{ fontFamily: "'Cormorant Garamond', Georgia, serif", fontSize: '1.5rem', color: '#ccc', fontStyle: 'italic', marginBottom: '0.5rem' }}>
              No products found
            </p>
            <p style={{ fontSize: '0.78rem', color: '#aaa', letterSpacing: '0.1em' }}>Try a different filter or search term</p>
          </div>
        ) : (
          <>
            <p style={{ fontSize: '0.65rem', color: '#aaa', letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: '2rem' }}>
              {filtered.length} item{filtered.length !== 1 ? 's' : ''} found
            </p>
            {/* 4-column grid like Sapphire */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
              gap: '1.5rem',
            }}>
              {filtered.map((product, i) => (
                <ProductCard key={product.id} product={product} index={i} />
              ))}
            </div>
          </>
        )}
      </div>

      {/* Footer */}
      <footer style={{
        background: '#111', borderTop: '0.5px solid rgba(184,150,12,0.2)',
        padding: '2rem 6vw', display: 'flex',
        alignItems: 'center', justifyContent: 'space-between',
        flexWrap: 'wrap', gap: '1rem',
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: "'Cormorant Garamond', Georgia, serif", fontSize: '0.9rem', fontWeight: 300, letterSpacing: '0.4em', textTransform: 'uppercase' }}>
  <span style={{ color: '#fff' }}>BRAND </span>
  <span style={{ color: '#b8960c' }}>BAZAR</span>
</div>
<div style={{ height: '1px', background: 'linear-gradient(to right, #0a0a0a, #b8960c, #0a0a0a)', margin: '4px auto', width: '80px' }} />
<div style={{ fontSize: '0.4rem', letterSpacing: '0.35em', color: '#b8960c', textTransform: 'uppercase' }}>BY MIRSA</div>
        </div>
        <div style={{ fontSize: '0.65rem', color: '#444', letterSpacing: '0.1em' }}>Pakistan&#39;s Most Trusted Multi-Brand Fashion Store</div>
      </footer>
    </>
  );
}
